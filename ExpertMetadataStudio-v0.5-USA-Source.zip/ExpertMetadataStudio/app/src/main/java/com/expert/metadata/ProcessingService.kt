package com.expert.metadata

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.net.Uri
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.util.concurrent.atomic.AtomicBoolean

class ProcessingService : Service() {
    companion object {
        const val START_ACTION = "com.expert.metadata.START"
        const val CANCEL_ACTION = "com.expert.metadata.CANCEL"
        const val UPDATE_ACTION = "com.expert.metadata.UPDATE"
        private const val CHANNEL = "media_processing"
        private const val NOTIFICATION_ID = 101
    }
    private val cancelled = AtomicBoolean(false)
    private val running = AtomicBoolean(false)
    private var worker: Thread? = null
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(
            NotificationChannel(CHANNEL, "Media processing", NotificationManager.IMPORTANCE_LOW)
        )
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == CANCEL_ACTION) {
            cancelled.set(true)
            worker?.interrupt()
            return START_NOT_STICKY
        }
        if (intent?.action != START_ACTION || !running.compareAndSet(false, true)) return START_NOT_STICKY
        @Suppress("DEPRECATION")
        val files = intent.getParcelableArrayListExtra<Uri>("uris") ?: arrayListOf()
        if (files.isEmpty()) { running.set(false); stopSelf(); return START_NOT_STICKY }
        cancelled.set(false)
        startForeground(NOTIFICATION_ID, notification("Starting processing", 0))
        worker = Thread {
            val reports = mutableListOf<String>()
            try {
                files.forEachIndexed { index, uri ->
                    if (cancelled.get()) return@Thread
                    val name = displayName(this, uri)
                    update("Processing ${index + 1}/${files.size}: $name", index.toFloat() / files.size, reports.joinToString("\n"), true)
                    val outcome = runCatching {
                        process(this, uri, { fraction ->
                            if (cancelled.get() || Thread.currentThread().isInterrupted) throw InterruptedException("Cancelled")
                            update("Processing ${index + 1}/${files.size}: $name", (index + fraction) / files.size, reports.joinToString("\n"), true)
                        }, if (intent.getBooleanExtra("synthetic_usa", false)) intent.getStringExtra("usa_city") else null)
                    }.fold({ "✓ $name → $it" }, { "✕ $name: ${it.message ?: "Failed"}" })
                    reports.add(outcome)
                }
            } finally {
                val label = if (cancelled.get()) "Cancelled" else "Finished. Check results."
                update(label, if (cancelled.get()) 0f else 1f, reports.joinToString("\n"), false)
                running.set(false)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }.also { it.start() }
        return START_NOT_STICKY
    }
    private fun notification(status: String, progress: Int): Notification {
        val cancel = PendingIntent.getService(this, 0, Intent(this, ProcessingService::class.java).setAction(CANCEL_ACTION), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Expert Metadata Studio")
            .setContentText(status)
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setProgress(100, progress.coerceIn(0, 100), false)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancel", cancel)
            .build()
    }
    private fun update(status: String, progress: Float, details: String, busy: Boolean) {
        val safe = progress.coerceIn(0f, 1f)
        if (busy) (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, notification(status, (safe * 100).toInt()))
        sendBroadcast(Intent(UPDATE_ACTION).setPackage(packageName).apply {
            putExtra("status", status); putExtra("progress", safe); putExtra("details", details); putExtra("busy", busy)
        })
    }
}
