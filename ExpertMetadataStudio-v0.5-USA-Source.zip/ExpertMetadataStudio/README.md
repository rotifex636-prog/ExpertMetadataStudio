# Expert Metadata Studio v0.5 — consolidated Android source

This is the **single consolidated source package** replacing the previous v0.1, v0.2 and v0.3 packages. It is NOT a verified APK build.

## Implemented in source
- Dark navy / cyan dashboard with **Metadata Cleaner & Editor** title.
- Android Gallery Photo Picker for videos/photos and Files picker; multiple selection; clear selection.
- MP4 audio/video sample stream-copy remux using Android MediaExtractor + MediaMuxer. Unsupported codecs/containers can fail; not a universal metadata sanitizer.
- JPEG and PNG bitmap decode/re-export (may alter image quality/size and remove many tags, but cannot guarantee every metadata trace is removed).
- Saves a **new copy** in Movies or Pictures / ExpertMetadataStudio using MediaStore; original unchanged.
- Foreground dataSync service, persistent progress notification, cancellation, and processing while app is backgrounded or screen locked (subject to Android OS limits).
- About/format/privacy explanation.
- GitHub Actions Android debug APK workflow.

## NOT implemented / not promised
- Arbitrary metadata editing, MOV/MKV/HEIC/WebM/AVI support, persistent resumable queue, fully reliable background execution after system termination, complete metadata verification, or production-ready privacy assurances.
- Some input MP4 streams are incompatible with MediaMuxer and may fail without transcoding.
- The progress bar is approximate; it is not a guaranteed time estimate.
- Metadata removal does not change audiovisual fingerprints or copyright ownership.

## Build
Extract ZIP. Upload project files including `.github/workflows/android-build.yml` to your GitHub repository. Run the **Android Debug APK** workflow from Actions. Install the APK artifact after a successful build and test MP4/JPEG/PNG, cancellation, and background processing on your device. Build has **not** been run or verified in this environment.

## Optional synthetic USA location
Enable in dashboard and choose New York, Los Angeles or Chicago. For MP4, Android MediaMuxer.setLocation writes coordinates into the newly remuxed container. These are explicitly synthetic, NOT original capture location or proof of origin. No fake camera, author, copyright ownership or timestamp is written. JPEG/PNG USA tagging is not implemented. This is not a guarantee that all old metadata is removed.
