package com.expert.metadata

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import androidx.compose.runtime.DisposableEffect
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val navy = Color(0xFF0B1425)
private val panel = Color(0xFF182A44)
private val blue = Color(0xFF38BDF8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var files by remember { mutableStateOf<List<Uri>>(emptyList()) }
            var busy by remember { mutableStateOf(false) }
            var showPicker by remember { mutableStateOf(false) }
            var showAbout by remember { mutableStateOf(false) }
            var usaProfile by remember { mutableStateOf(false) }
            var usaCity by remember { mutableStateOf("New York") }
            var progress by remember { mutableFloatStateOf(0f) }
            var status by remember { mutableStateOf("Select videos or images to begin.") }
            var details by remember { mutableStateOf("") }
            val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(30)) { files = it; status = "${it.size} item(s) selected from Gallery" }
            val browse = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { files = it; status = "${it.size} item(s) selected from Files" }
            DisposableEffect(Unit) {
                val receiver = object : BroadcastReceiver() {
                    override fun onReceive(context: Context, intent: Intent) {
                        progress = intent.getFloatExtra("progress", progress)
                        status = intent.getStringExtra("status") ?: status
                        details = intent.getStringExtra("details") ?: details
                        busy = intent.getBooleanExtra("busy", busy)
                    }
                }
                val filter = IntentFilter(ProcessingService.UPDATE_ACTION)
                androidx.core.content.ContextCompat.registerReceiver(this@MainActivity, receiver, filter, androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED)
                onDispose { unregisterReceiver(receiver) }
            }
            MaterialTheme(colorScheme = darkColorScheme(primary = blue, background = navy, surface = panel)) {
                Column(Modifier.fillMaxSize().background(navy).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Spacer(Modifier.height(10.dp))
                    Text("◈ Expert Metadata Studio", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("PRIVATE MEDIA CLEANER  •  VERSION 0.4", color = blue, fontSize = 11.sp)
                    Card(colors = CardDefaults.cardColors(containerColor = panel)) {
                        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Metadata Cleaner & Editor", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                            Text("Clean supported metadata • Preserve originals", color = Color.LightGray)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Synthetic USA location (MP4 only)", color = Color.White)
                                Switch(checked = usaProfile, onCheckedChange = { usaProfile = it }, enabled = !busy)
                            }
                            if (usaProfile) {
                                Text("Clearly synthetic location; not proof of recording place", color = Color.LightGray, fontSize = 12.sp)
                                listOf("New York", "Los Angeles", "Chicago").forEach { city ->
                                    Row { RadioButton(selected = usaCity == city, onClick = { usaCity = city }, enabled = !busy); Text(city, Modifier.padding(top = 12.dp), color = Color.White) }
                                }
                            }
                            Button(onClick = { showPicker = true }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("SELECT MEDIA") }
                            if (showPicker) {
                                AlertDialog(onDismissRequest = { showPicker = false }, title = { Text("Select Media") }, text = {
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(onClick = { showPicker = false; gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) }, modifier = Modifier.fillMaxWidth()) { Text("Choose from Gallery") }
                                        OutlinedButton(onClick = { showPicker = false; browse.launch(arrayOf("video/*", "image/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Browse Files") }
                                        Text("Select multiple photos or videos. Camera recording is planned.", fontSize = 12.sp)
                                    }
                                }, confirmButton = { TextButton(onClick = { showPicker = false }) { Text("Close") } })
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Selected files (${files.size})", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                        TextButton(onClick = { files = emptyList(); status = "Selection cleared." }, enabled = !busy && files.isNotEmpty()) { Text("Clear All") }
                    }
                    files.take(30).forEach { uri ->
                        val name = remember(uri) { displayName(this@MainActivity, uri) }
                        Card(colors = CardDefaults.cardColors(containerColor = panel)) { Text(name, Modifier.fillMaxWidth().padding(14.dp), color = Color.White) }
                    }
                    Button(enabled = files.isNotEmpty() && !busy, modifier = Modifier.fillMaxWidth(), onClick = {
                        busy = true; progress = 0f; details = ""
                        val work = Intent(this@MainActivity, ProcessingService::class.java).apply {
                            action = ProcessingService.START_ACTION
                            putParcelableArrayListExtra("uris", ArrayList(files))
                            putExtra("synthetic_usa", usaProfile)
                            putExtra("usa_city", usaCity)
                        }
                        androidx.core.content.ContextCompat.startForegroundService(this@MainActivity, work)
                        status = "Processing in background. You may leave the app."

                    }) { Text(if (busy) "PROCESSING…" else "START CLEANING") }
                    if (busy) OutlinedButton(onClick = {
                        startService(Intent(this@MainActivity, ProcessingService::class.java).setAction(ProcessingService.CANCEL_ACTION))
                    }, modifier = Modifier.fillMaxWidth()) { Text("CANCEL PROCESSING") }
                    if (busy || progress > 0f) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                    Text(status, color = blue)
                    if (details.isNotBlank()) Card(colors = CardDefaults.cardColors(containerColor = panel)) {
                        Text(details, Modifier.fillMaxWidth().padding(16.dp), color = Color.White)
                    }
                    OutlinedButton(onClick = { showAbout = true }, modifier = Modifier.fillMaxWidth()) { Text("ABOUT • FORMATS • PRIVACY") }
                    if (showAbout) AlertDialog(onDismissRequest = { showAbout = false }, title = { Text("About Expert Metadata Studio") }, text = {
                        Text("Gallery + Files selection, batch processing, foreground notification, cancel, MP4 remux, JPEG/PNG raster export. Output: Movies/Pictures/ExpertMetadataStudio. Original remains unchanged. Optional synthetic USA MP4 location is supported; manual tag editing, resumable queue and other formats are not implemented.")
                    }, confirmButton = { TextButton(onClick = { showAbout = false }) { Text("Close") } })
                    Text("Supported: MP4 remux (video/audio stream copy), JPEG and PNG image export. Other formats show an error. Output goes to Movies or Pictures / ExpertMetadataStudio. Originals remain unchanged.", color = Color.LightGray, fontSize = 12.sp)
                    Text("This app removes supported container metadata; it does not remove visible watermarks, audio/video fingerprints, or guarantee removal of every embedded tag. Optional synthetic USA coordinates can be written to MP4 when enabled; they are not authentic recording provenance. No ownership claims are written.", color = Color.LightGray, fontSize = 12.sp)
                }
            }
        }
    }
}

internal fun displayName(context: Context, uri: Uri): String = runCatching {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0) else null
    } ?: "media"
}.getOrDefault("media")

internal fun process(context: Context, uri: Uri, onProgress: (Float) -> Unit, usaCity: String? = null): String {
    val resolver = context.contentResolver
    val mime = resolver.getType(uri).orEmpty().lowercase(Locale.US)
    val filename = displayName(context, uri)
    val extension = filename.substringAfterLast('.', "").lowercase(Locale.US)
    val isMp4 = mime == "video/mp4" || extension == "mp4" || extension == "m4v"
    val isJpeg = mime == "image/jpeg" || extension == "jpg" || extension == "jpeg"
    val isPng = mime == "image/png" || extension == "png"
    require(isMp4 || isJpeg || isPng) { "Only MP4, JPEG and PNG supported in this build" }
    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
    val outName = "Clean_${stamp}.${if (isMp4) "mp4" else if (isPng) "png" else "jpg"}"
    val temp = File.createTempFile("expert_clean_", if (isMp4) ".mp4" else ".img", context.cacheDir)
    try {
        if (isMp4) remuxMp4(context, uri, temp, onProgress, usaCity) else {
            resolver.openInputStream(uri)?.use { input ->
                val bitmap = BitmapFactory.decodeStream(input) ?: error("Cannot decode image")
                temp.outputStream().use { output ->
                    val format = if (isPng) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
                    check(bitmap.compress(format, if (isPng) 100 else 95, output)) { "Image export failed" }
                }
                bitmap.recycle()
            } ?: error("Cannot open image")
            onProgress(0.85f)
        }
        check(temp.length() > 0L) { "Output is empty" }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, outName)
            put(MediaStore.MediaColumns.MIME_TYPE, if (isMp4) "video/mp4" else if (isPng) "image/png" else "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, (if (isMp4) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES) + "/ExpertMetadataStudio")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection = if (isMp4) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val destination = resolver.insert(collection, values) ?: error("Cannot create output in media library")
        try {
            resolver.openOutputStream(destination)?.use { output -> temp.inputStream().use { it.copyTo(output) } } ?: error("Cannot write output")
            resolver.update(destination, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
        } catch (e: Exception) { resolver.delete(destination, null, null); throw e }
        onProgress(1f)
        return outName
    } finally { temp.delete() }
}

private fun remuxMp4(context: Context, uri: Uri, output: File, onProgress: (Float) -> Unit, usaCity: String?) {
    val extractor = MediaExtractor()
    var muxer: MediaMuxer? = null
    try {
        context.contentResolver.openFileDescriptor(uri, "r")?.use { descriptor ->
            extractor.setDataSource(descriptor.fileDescriptor)
            val tracks = mutableMapOf<Int, Int>()
            val m = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = m
            when (usaCity) {
                "New York" -> m.setLocation(40.7128f, -74.0060f)
                "Los Angeles" -> m.setLocation(34.0522f, -118.2437f)
                "Chicago" -> m.setLocation(41.8781f, -87.6298f)
            }
            var maxBuffer = 1024 * 1024
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(android.media.MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    tracks[i] = m.addTrack(format)
                    extractor.selectTrack(i)
                    if (format.containsKey(android.media.MediaFormat.KEY_MAX_INPUT_SIZE)) {
                        maxBuffer = maxOf(maxBuffer, format.getInteger(android.media.MediaFormat.KEY_MAX_INPUT_SIZE).coerceAtMost(32 * 1024 * 1024))
                    }
                }
            }
            check(tracks.isNotEmpty()) { "No compatible audio/video tracks" }
            m.start()
            val buffer = ByteBuffer.allocateDirect(maxBuffer)
            val info = MediaCodec.BufferInfo()
            val duration = (0 until extractor.trackCount).mapNotNull { i ->
                val f = extractor.getTrackFormat(i)
                if (f.containsKey(android.media.MediaFormat.KEY_DURATION)) f.getLong(android.media.MediaFormat.KEY_DURATION) else null
            }.maxOrNull() ?: 0L
            while (true) {
                val track = extractor.sampleTrackIndex
                if (track < 0) break
                val mapped = tracks[track]
                if (mapped == null) { extractor.advance(); continue }
                buffer.clear()
                val size = extractor.readSampleData(buffer, 0)
                if (size < 0) break
                info.offset = 0
                info.size = size
                info.presentationTimeUs = extractor.sampleTime
                info.flags = extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC
                m.writeSampleData(mapped, buffer, info)
                if (duration > 0L) onProgress((info.presentationTimeUs.toFloat() / duration).coerceIn(0f, 0.90f))
                extractor.advance()
            }
            m.stop()
        } ?: error("Cannot open video")
    } finally {
        runCatching { muxer?.release() }
        extractor.release()
    }
}
